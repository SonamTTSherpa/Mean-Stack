module.exports = {
    greet: function(){
        console.log("we are now using a module!");
    }
}