var my_module = require('./my_module');
my_module.greet();